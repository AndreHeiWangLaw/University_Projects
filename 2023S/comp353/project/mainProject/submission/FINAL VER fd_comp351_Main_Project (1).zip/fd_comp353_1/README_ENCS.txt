
ATTENTION: this directory (folder) is for web-accessible, PUBLIC data.
           Do not store your private files here!

If you don't need to see this reminder any more, you can delete this file.
