Andre Hei Wang Law
4017 5600
L_HEIWAN

==ASSIGNMENT 1 COMP 371==

[Information]
-The solution project is found inside:
	\Lab04\Lab_Framework\VS2017\Labs.sln
-The source code (lab04.cpp) is found inside:
	\Lab04\Lab_Framework\Source
-The skeleton of this project was based on lab 4


[Controls]
Repositioning the Model:
	"spacebar" =  re-position at a random

Sizing the Model up and down:
	"u" = size up
	"j" = size down

Update Model position:
	"w" = move up
	"a" = move left
	"s" = move down
	"d" = move right

Model rotation around Z-axis: 
	"q" = rotate left
	"e" = rotate right

Model rotation around Y-axis: 
	"z" = rotate left
	"c" = rotate right

Changing world orientation: 
	"left arrow" = orientate left 
	"right arrow" = orientate right
	"up arrow" = orientate up
	"down arrow" = orientate down
	"home" = reset

Rendering modes (P, L, T):
	"p" = points mode
	"l" = line mode
	"t" = triangle mode

Camera tilt and pan:
	"middle button pressed" + move up/down = tilt
	"right button pressed" + move left/right = pan

Camera zoom (in and out): 
	"left button pressed" + move out = zoom out
	"left button pressed" + move in = zoom out

Additional controls:
	"esc" = exit program
