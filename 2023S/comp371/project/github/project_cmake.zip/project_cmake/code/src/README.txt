QUIZ 2 CONTROLS
F - Rotate world anticlockwise around x
T - Rotate world anticlockwise around y
G - Rotate world clockwise around y
H - Rotate world clockwise around x
Left arrow - Rotate y spotlight clockwise
Up arrow - Change camera postion to y spotlight
Right arrow - Rotate y spotlight counterclockwise
X - toggle textures
B - toggle shadow
L - toggle z spotlight
K - toggle y spotlight
J - toggle z spotlight rotation
P - change model rendering to using points
O - change model rendering to using lines
I - change model rendering to use triangles
While right mouse button is pressed - move right to pan to the right, left to pan to the left
while middle mouse button is pressed - move up to tilt downwards, down to tilt upwards
While left mouse button is pressed - move up to zoom in, down to zoom out

1 - Select player 1 racket
2 - Select player 2 racket

These controls only work when a racket is selected
uppercase A - move model left
W - move model forwards
S - move model backwards
uppercase D - move model right
lowercase a - rotate model left about the Y axis
lowercase d - rotate model right about the Y axis